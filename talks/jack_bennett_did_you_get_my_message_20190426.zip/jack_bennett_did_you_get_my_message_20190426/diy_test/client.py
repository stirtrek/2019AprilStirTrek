# Echo client program
#
# https://docs.python.org/2/library/socket.html

import random
import socket
import time

HOST = 'localhost'    # The remote host
PORT = 50007          # The same port as used by the server

# ------------------------------------------------------------
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    MAX_COUNT = 1000000
    count = 0
    while True:
        # construct a message with random ID
        msg_id = str(random.randint(0,100000))
        msg_payload = b'Hello, world [' + bytes(msg_id, 'utf-8') + b']'

        # send message to server
        s.sendall(msg_payload)
        print('[client] sent', repr(msg_payload))

        # receive echo back from server
        data = s.recv(1024)
        print('[client] Received %s from server' % repr(data))
        time.sleep(1)
        count += 1
        if count > MAX_COUNT:
            break

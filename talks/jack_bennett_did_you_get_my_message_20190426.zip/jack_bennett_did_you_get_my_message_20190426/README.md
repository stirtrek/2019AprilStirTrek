"Did you get my message?" - A comparison of three modern messaging frameworks

*MESSAGING DEMO CODE*

Jack Bennett
Stir Trek
2019-04-26

- Python virtual environments are recommended for each of the separate demos

- All the demos use Python 3 code (I used 3.6 but any recent 3.x version should be fine)

- External dependencies are as defined (imported) in the indivdual scripts

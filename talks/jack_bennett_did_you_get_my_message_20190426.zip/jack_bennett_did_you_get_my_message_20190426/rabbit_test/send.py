#!/usr/bin/env python
import pika
import random
import time

connection = pika.BlockingConnection(
                        pika.ConnectionParameters(host='localhost')
                        )
channel = connection.channel()
channel.queue_declare(queue='hello_queue')

# ------------------------------------------------------------
# loop and send messages with random ID
MAX_COUNT = 1000000
count = 0
while True:
    message_id = random.randint(0,1000000)
    message_text ='Hello World! [' + str(message_id) + "]"

    channel.basic_publish(
        exchange='',
        routing_key='hello_queue',
        body=message_text,
    )
    print(" [sender] Sent '{}'".format(message_text))
    time.sleep(0.5)
    count += 1
    if count > MAX_COUNT:
        break
connection.close()

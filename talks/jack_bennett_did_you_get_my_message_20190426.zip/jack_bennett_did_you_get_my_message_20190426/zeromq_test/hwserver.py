#
#   Hello World server in Python
#   Binds REP (reply) socket to tcp://*:5555
#
#   Expects b"Hello" from client, replies with b"World"
#

import time
import zmq

print("setting up socket context and listening")
context = zmq.Context()
socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")
print("listening now")

# sm_index = 1
# MAX_COUNT = 1000000
count = 0
while True:
    #  Wait for next request from client
    message = socket.recv()
    print("Received request: '%s'" % message)

    #  Do some 'work'
    time.sleep(1)

    #  Send reply back to client
    reply_msg = "World " + str(count)
    socket.send(bytes(reply_msg, 'utf-8'))
    print("sent reply '%s'" % reply_msg)
    count += 1

    if count % 100000 == 0:
        print(count)

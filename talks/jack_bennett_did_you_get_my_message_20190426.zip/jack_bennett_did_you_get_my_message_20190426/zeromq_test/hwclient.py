#
#   Hello World client in Python
#   Connects REQ (request) socket to tcp://localhost:5555
#   Sends "Hello" to server, expects "World" back
#

import random
import zmq

context = zmq.Context()

# ------------------------------------------------------------
#  Socket to talk to server
print("Connecting to hello world server...")
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5555")
print("connected to hello world server")

# ------------------------------------------------------------
#  Do MAX_COUNT requests, waiting each time for a response
MAX_COUNT = 1000000
for request in range(MAX_COUNT):
    cm_id = random.randint(0,1000000)
    print("Sending request #%d with ID %d" % (request, cm_id))
    msg = b"Hello [%d]" % cm_id
    socket.send(b"Hello [%d]" % cm_id)

    #  Get the reply.
    message = socket.recv()
    print("Received reply %s [ %s ]" % (request, message))

    if request % 100000 == 0:
        print(request)

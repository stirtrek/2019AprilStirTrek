from kafka import KafkaConsumer

TOPIC_NAME = 'foobar'
HOST = "localhost:9092"

consumer = KafkaConsumer(
    TOPIC_NAME,
    bootstrap_servers=HOST
)
# consumer.seek_to_beginning()
for msg in consumer:
    print(msg)

import random
import time

from kafka import KafkaProducer

TOPIC_NAME = 'foobar'
HOST = "localhost:9092"

producer = KafkaProducer(bootstrap_servers=HOST)
MAX_COUNT = 1000000
for _ in range(MAX_COUNT):
    msg = 'some_message_bytes [%d]' % random.randint(1,100000)
    # print("sending message: '%s'" % msg)
    producer.send(
        TOPIC_NAME,
        bytes('some_message_bytes [%d]' % random.randint(1,100000), 'utf-8')
    )
    # time.sleep(0.1)
